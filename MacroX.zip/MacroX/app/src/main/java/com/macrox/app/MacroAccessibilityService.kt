package com.macrox.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var inst: MacroAccessibilityService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val runners = HashMap<Long, Runner>()

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAll() }
    override fun onUnbind(intent: Intent?): Boolean {
        inst = null
        stopAll()
        return super.onUnbind(intent)
    }

    fun isRunning(id: Long) = runners.containsKey(id)

    fun play(m: Macro, onEnd: () -> Unit) {
        stop(m.id)
        val r = Runner(m, onEnd)
        runners[m.id] = r
        r.round()
    }

    fun stop(id: Long) { runners.remove(id)?.cancel() }

    fun stopAll() {
        val l = runners.values.toList()
        runners.clear()
        l.forEach { it.cancel() }
    }

    private inner class Runner(val m: Macro, val onEnd: () -> Unit) {
        var alive = true
        var iter = 0

        fun round() {
            if (!alive) return
            val sp = m.speed.coerceIn(0.25f, 4f)
            // Mỗi thao tác được hẹn giờ riêng theo đúng thời điểm đã ghi
            for (s in m.steps) {
                main.postDelayed({ if (alive) fire(s, sp) }, (s.t / sp).toLong())
            }
            val total = (m.totalMs / sp).toLong() + m.gapMs + 30
            main.postDelayed({
                if (!alive) return@postDelayed
                iter++
                if (m.loops == 0 || iter < m.loops) round() else finish()
            }, total)
        }

        fun finish() {
            alive = false
            runners.remove(m.id)
            onEnd()
        }

        fun cancel() {
            if (!alive) return
            alive = false
            onEnd()
        }
    }

    private fun fire(s: Step, sp: Float) {
        if (s.pts.size < 2) return
        val p = Path()
        p.moveTo(s.pts[0], s.pts[1])
        var i = 2
        while (i + 1 < s.pts.size) { p.lineTo(s.pts[i], s.pts[i + 1]); i += 2 }
        val dur = (s.d / sp).toLong().coerceIn(1L, 59000L)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        dispatchGesture(g, null, null)
    }
}
