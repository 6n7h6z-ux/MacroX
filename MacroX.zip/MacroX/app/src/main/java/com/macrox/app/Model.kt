package com.macrox.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Một thao tác: bắt đầu ở t (ms), kéo dài d (ms), đi qua các điểm x0,y0,x1,y1... */
class Step(val t: Long, val d: Long, val pts: List<Float>)

class Macro(
    val id: Long,
    var name: String,
    var steps: List<Step>,
    var loops: Int = 1,          // 0 = lặp vô hạn
    var speed: Float = 1f,
    var gapMs: Long = 0,
    var onScreen: Boolean = false,
    var label: String = "",
    var btnDp: Int = 56,
    var btnAlpha: Float = 0.9f,
    var btnX: Int = 200,
    var btnY: Int = 200
) {
    val totalMs: Long get() = steps.maxOfOrNull { it.t + it.d } ?: 0L
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("macrox", Context.MODE_PRIVATE)
    var bx = sp.getInt("bx", 30)
    var by = sp.getInt("by", 300)
    var bubbleDp = sp.getInt("bdp", 48)
    var bubblePct = sp.getInt("bpct", 90)
    var hotOn = sp.getBoolean("hot", true)
    var hotPct = sp.getInt("hpct", 25)
    val macros = mutableListOf<Macro>()

    init {
        try {
            val s = sp.getString("macros", null)
            if (s != null) {
                val a = JSONArray(s)
                for (i in 0 until a.length()) macros.add(fromJson(a.getJSONObject(i)))
            }
        } catch (_: Exception) {
        }
    }

    fun save() {
        val arr = JSONArray()
        macros.forEach { arr.put(toJson(it)) }
        sp.edit()
            .putInt("bx", bx).putInt("by", by)
            .putInt("bdp", bubbleDp).putInt("bpct", bubblePct)
            .putBoolean("hot", hotOn).putInt("hpct", hotPct)
            .putString("macros", arr.toString())
            .apply()
    }

    private fun toJson(m: Macro): JSONObject {
        val o = JSONObject()
        o.put("id", m.id); o.put("name", m.name); o.put("loops", m.loops)
        o.put("speed", m.speed.toDouble()); o.put("gap", m.gapMs); o.put("on", m.onScreen)
        o.put("label", m.label); o.put("dp", m.btnDp); o.put("alpha", m.btnAlpha.toDouble())
        o.put("x", m.btnX); o.put("y", m.btnY)
        val sa = JSONArray()
        for (s in m.steps) {
            val so = JSONObject()
            so.put("t", s.t); so.put("d", s.d)
            so.put("p", JSONArray(s.pts.map { it.toDouble() }))
            sa.put(so)
        }
        o.put("steps", sa)
        return o
    }

    private fun fromJson(o: JSONObject): Macro {
        val sa = o.getJSONArray("steps")
        val steps = ArrayList<Step>()
        for (i in 0 until sa.length()) {
            val s = sa.getJSONObject(i)
            val pa = s.getJSONArray("p")
            val pts = ArrayList<Float>()
            for (j in 0 until pa.length()) pts.add(pa.getDouble(j).toFloat())
            steps.add(Step(s.getLong("t"), s.getLong("d"), pts))
        }
        val name = o.getString("name")
        return Macro(
            o.getLong("id"), name, steps,
            o.optInt("loops", 1), o.optDouble("speed", 1.0).toFloat(), o.optLong("gap", 0),
            o.optBoolean("on", false), o.optString("label", name),
            o.optInt("dp", 56), o.optDouble("alpha", 0.9).toFloat(),
            o.optInt("x", 200), o.optInt("y", 200)
        )
    }
}
