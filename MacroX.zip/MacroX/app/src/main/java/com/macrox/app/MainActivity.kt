package com.macrox.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)
        status = TextView(this)
        status.textSize = 15f
        root.addView(status)
        fun add(t: String, a: () -> Unit) {
            val bt = Button(this)
            bt.text = t
            bt.setOnClickListener { a() }
            root.addView(bt)
        }
        add("1. Cấp quyền hiển thị trên ứng dụng khác") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        add("2. Bật Trợ năng cho Macro X") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        add("3. Bỏ tối ưu pin (nên làm)") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        add("4. Bật menu nổi") { startOverlay() }
        add("Tắt menu nổi") { stopService(Intent(this, OverlayService::class.java)) }
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val o = if (Settings.canDrawOverlays(this)) "✔" else "✘"
        val a = if (MacroAccessibilityService.inst != null) "✔" else "✘"
        status.text = "Hiển thị trên ứng dụng khác: $o\nTrợ năng: $a\n" +
            "(Android 13+: nếu không bật được Trợ năng, vào Cài đặt > Ứng dụng > Macro X > ⋮ > Cho phép cài đặt bị hạn chế)"
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Chưa cấp quyền hiển thị trên ứng dụng khác", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        startForegroundService(Intent(this, OverlayService::class.java))
    }
}
