package com.macrox.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "com.macrox.app.STOP"
    }

    private val BLUE = 0xFF1E88E5.toInt()
    private val GRAY = 0xFF3A3F4B.toInt()
    private val RED = 0xFFC0392B.toInt()
    private val DARKRED = 0xFF5A2A2A.toInt()
    private val GREEN = 0xFF2E7D32.toInt()
    private val ORANGE = 0xFFEF6C00.toInt()
    private val MUTED = 0xFF9AA0A6.toInt()
    private val CARD = 0xFF23262E.toInt()
    private val PANEL = 0xF2181A20.toInt()

    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private val main = Handler(Looper.getMainLooper())
    private var started = false

    private var bubble: TextView? = null
    private var bubbleP: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var panelOpen = false
    private var hotspot: View? = null
    private val btns = HashMap<Long, TextView>()
    private val btnP = HashMap<Long, WindowManager.LayoutParams>()
    private var arrange = false
    private var tab = 0
    private var recLayer: View? = null
    private var recBar: View? = null
    private val recSteps = mutableListOf<Step>()

    private val dm get() = resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = Store(this)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!started) {
            started = true
            startFg()
            showBubble()
            syncButtons()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        MacroAccessibilityService.inst?.stopAll()
        listOf(bubble, panel, hotspot, recLayer, recBar).forEach { v -> v?.let { rm(it) } }
        btns.values.toList().forEach { rm(it) }
        btns.clear()
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Macro X", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "ov")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Macro X đang chạy")
            .addAction(0, "Tắt", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- tiện ích giao diện ----------
    private fun rm(v: View) { try { wm.removeView(v) } catch (_: Exception) {} }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun lp(
        w: Int, h: Int, x: Int = 0, y: Int = 0,
        gravity: Int = Gravity.TOP or Gravity.START, focusable: Boolean = false
    ): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!focusable) f = f or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val p = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT)
        p.gravity = gravity; p.x = x; p.y = y
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return p
    }

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun tv(text: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
    }

    private fun btn(text: String, bg: Int, onClick: () -> Unit) = tv(text, 13f).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = rounded(bg, 14)
        setOnClickListener { onClick() }
    }

    private fun sbtn(t: String, a: () -> Unit) = btn(t, GRAY, a).apply { setPadding(dp(10), dp(4), dp(10), dp(4)) }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun LinearLayout.put(v: View, w: Int = WRAP_CONTENT, h: Int = WRAP_CONTENT, wt: Float = 0f): View {
        val p = LinearLayout.LayoutParams(w, h, wt)
        p.setMargins(dp(3), dp(3), dp(3), dp(3))
        addView(v, p)
        return v
    }

    /** Nút tròn có chữ tự co để luôn nằm gọn trong nút. */
    private fun circleView(text: String, color: Int, sizePx: Int, alpha: Float) = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        maxLines = 2
        val pad = (sizePx * 0.15f).toInt()
        setPadding(pad, pad, pad, pad)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(1), 0x66FFFFFF) }
        setAutoSizeTextTypeUniformWithConfiguration(6, 64, 1, TypedValue.COMPLEX_UNIT_SP)
        this.alpha = alpha
    }

    /** Kéo thả bằng đúng 1 ngón của chính cửa sổ này, không đụng tới thao tác của game. */
    private fun drag(
        v: View, p: WindowManager.LayoutParams,
        canDrag: () -> Boolean, onTap: () -> Unit, onMoved: () -> Unit
    ) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> if (canDrag()) {
                    val ox = e.rawX - dx; val oy = e.rawY - dy
                    if (!moved && hypot(ox, oy) > slop) moved = true
                    if (moved) { p.x = sx + ox.toInt(); p.y = sy + oy.toInt(); try { wm.updateViewLayout(view, p) } catch (_: Exception) {} }
                }
                MotionEvent.ACTION_UP -> if (moved) onMoved() else onTap()
                MotionEvent.ACTION_CANCEL -> if (moved) onMoved()
            }
            true
        }
    }

    // ---------- bong bóng menu ----------
    private fun showBubble() {
        val size = dp(store.bubbleDp)
        val p = lp(size, size, store.bx, store.by)
        val v = circleView("M", BLUE, size, store.bubblePct / 100f)
        drag(v, p, { true }, { togglePanel() }, { store.bx = p.x; store.by = p.y; store.save() })
        wm.addView(v, p)
        bubble = v; bubbleP = p
    }

    private fun applyBubble() {
        val v = bubble ?: return
        val p = bubbleP ?: return
        val size = dp(store.bubbleDp)
        p.width = size; p.height = size
        val pad = (size * 0.15f).toInt(); v.setPadding(pad, pad, pad, pad)
        v.alpha = store.bubblePct / 100f
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun bringBubbleFront() {
        val v = bubble ?: return
        val p = bubbleP ?: return
        rm(v)
        wm.addView(v, p)
    }

    private fun togglePanel() { if (panelOpen) closePanel() else openPanel() }

    private fun openPanel() {
        val w = min(max((dm.widthPixels * 0.5f).toInt(), dp(340)), dm.widthPixels - dp(24))
        val h = (dm.heightPixels * 0.8f).toInt()
        val root = col().apply {
            background = rounded(PANEL, 20)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        wm.addView(root, lp(w, h, 0, 0, Gravity.CENTER))
        panel = root; panelOpen = true
        renderPanel()
        main.post { bringBubbleFront() }
    }

    private fun closePanel() {
        panel?.let { rm(it) }
        panel = null; panelOpen = false
    }

    // ---------- ẩn / hiện toàn bộ menu ----------
    private fun hideAll() {
        closePanel()
        bubble?.let { rm(it) }
        bubble = null
        val p = bubbleP ?: return
        val size = dp(store.bubbleDp)
        val a = if (store.hotOn) max(1, store.hotPct * 255 / 100) else 1
        val hv = View(this)
        hv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(a, 255, 255, 255))
            if (store.hotOn) setStroke(dp(2), Color.argb(min(255, a * 2), 255, 255, 255))
        }
        hv.setOnClickListener { main.post { showAll() } }
        wm.addView(hv, lp(size, size, p.x, p.y))
        hotspot = hv
    }

    private fun showAll() {
        hotspot?.let { rm(it) }
        hotspot = null
        showBubble()
    }

    // ---------- giao diện menu ----------
    private fun renderPanel() {
        val root = panel ?: return
        root.removeAllViews()
        val head = row()
        head.put(tv("Macro X", 18f).apply { setTypeface(null, Typeface.BOLD) }, 0, WRAP_CONTENT, 1f)
        head.put(btn("Sắp xếp", if (arrange) BLUE else GRAY) { arrange = !arrange; applyArrange(); renderPanel() })
        head.put(btn("Ẩn menu", DARKRED) { hideAll() })
        root.put(head, MATCH_PARENT)
        val tabs = row()
        listOf("Macro", "Nút", "Cài đặt").forEachIndexed { i, n ->
            tabs.put(btn(n, if (tab == i) BLUE else GRAY) { tab = i; renderPanel() }, 0, WRAP_CONTENT, 1f)
        }
        root.put(tabs, MATCH_PARENT)
        val sv = ScrollView(this)
        val c = col()
        sv.addView(c)
        when (tab) { 0 -> tabMacro(c); 1 -> tabButtons(c); else -> tabSettings(c) }
        root.put(sv, MATCH_PARENT, 0, 1f)
    }

    private fun stepper(title: String, value: String, minus: () -> Unit, plus: () -> Unit): LinearLayout {
        val r = row()
        r.put(tv("$title ", 12f, MUTED))
        r.put(sbtn("−", minus))
        r.put(tv(value, 13f).apply { gravity = Gravity.CENTER; minWidth = dp(34) })
        r.put(sbtn("+", plus))
        return r
    }

    private fun sliderRow(title: String, lo: Int, hi: Int, cur: Int, unit: String, onChange: (Int) -> Unit): View {
        val r = row()
        val t = tv("$title: $cur$unit", 13f)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = cur - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                t.text = "$title: ${p + lo}$unit"
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { store.save() }
        })
        r.put(t, dp(140))
        r.put(sb, 0, WRAP_CONTENT, 1f)
        return r
    }

    private fun cardView() = col().apply {
        background = rounded(CARD, 14)
        setPadding(dp(10), dp(8), dp(10), dp(8))
    }

    private fun tabMacro(c: LinearLayout) {
        c.put(btn("● Ghi macro mới", RED) { startRecording() }, MATCH_PARENT)
        if (store.macros.isEmpty()) c.put(tv("Chưa có macro nào. Bấm nút đỏ để ghi.", 13f, MUTED))
        for (m in store.macros.toList()) {
            val card = cardView()
            val r1 = row()
            val info = col()
            info.put(tv(m.name, 16f).apply { setTypeface(null, Typeface.BOLD) })
            info.put(tv("${m.steps.size} thao tác · ${"%.1f".format(m.totalMs / 1000f)} giây", 12f, MUTED))
            r1.put(info, 0, WRAP_CONTENT, 1f)
            val running = MacroAccessibilityService.inst?.isRunning(m.id) == true
            r1.put(btn(if (running) "■" else "▶", if (running) RED else GREEN) { toggleRun(m); renderPanel() })
            r1.put(btn(if (m.onScreen) "Gỡ nút" else "Đặt nút", if (m.onScreen) ORANGE else GRAY) {
                m.onScreen = !m.onScreen; store.save(); syncButtons(); renderPanel()
            })
            r1.put(btn("✎", GRAY) { prompt("Đổi tên macro", m.name) { m.name = it; store.save(); renderPanel() } })
            r1.put(btn("⧉", GRAY) {
                store.macros.add(Macro(System.currentTimeMillis(), m.name + " (2)", m.steps, m.loops, m.speed, m.gapMs,
                    false, m.label, m.btnDp, m.btnAlpha, m.btnX + dp(20), m.btnY + dp(20)))
                store.save(); renderPanel()
            })
            r1.put(btn("✕", DARKRED) {
                MacroAccessibilityService.inst?.stop(m.id)
                store.macros.remove(m); store.save(); syncButtons(); renderPanel()
            })
            card.put(r1, MATCH_PARENT)
            val r2 = row()
            r2.put(stepper("Lặp", if (m.loops == 0) "∞" else "${m.loops}",
                { m.loops = max(0, m.loops - 1); store.save(); renderPanel() },
                { m.loops += 1; store.save(); renderPanel() }), 0, WRAP_CONTENT, 1f)
            r2.put(stepper("Tốc độ", "%.2fx".format(m.speed),
                { m.speed = max(0.25f, m.speed - 0.25f); store.save(); renderPanel() },
                { m.speed = min(4f, m.speed + 0.25f); store.save(); renderPanel() }), 0, WRAP_CONTENT, 1f)
            r2.put(stepper("Nghỉ", "${m.gapMs}ms",
                { m.gapMs = max(0L, m.gapMs - 100); store.save(); renderPanel() },
                { m.gapMs = min(5000L, m.gapMs + 100); store.save(); renderPanel() }), 0, WRAP_CONTENT, 1f)
            card.put(r2, MATCH_PARENT)
            c.put(card, MATCH_PARENT)
        }
    }

    private fun tabButtons(c: LinearLayout) {
        if (store.macros.isEmpty()) c.put(tv("Chưa có macro nào.", 13f, MUTED))
        for (m in store.macros.toList()) {
            val card = cardView()
            val r1 = row()
            r1.put(tv(m.name, 16f).apply { setTypeface(null, Typeface.BOLD) }, 0, WRAP_CONTENT, 1f)
            r1.put(btn(if (m.onScreen) "Đang hiện" else "Đang ẩn", if (m.onScreen) GREEN else GRAY) {
                m.onScreen = !m.onScreen; store.save(); syncButtons(); renderPanel()
            })
            card.put(r1, MATCH_PARENT)
            val r2 = row()
            r2.put(tv("Chữ trên nút: ${m.label}", 13f), 0, WRAP_CONTENT, 1f)
            r2.put(btn("Sửa chữ", BLUE) {
                prompt("Chữ trên nút", m.label) { m.label = it; store.save(); refreshButton(m); renderPanel() }
            })
            card.put(r2, MATCH_PARENT)
            card.put(sliderRow("Cỡ nút", 24, 140, m.btnDp, "dp") { m.btnDp = it; refreshButton(m) }, MATCH_PARENT)
            card.put(sliderRow("Độ đậm", 20, 100, (m.btnAlpha * 100).toInt(), "%") { m.btnAlpha = it / 100f; refreshButton(m) }, MATCH_PARENT)
            c.put(card, MATCH_PARENT)
        }
    }

    private fun tabSettings(c: LinearLayout) {
        val card = cardView()
        card.put(tv("Bong bóng menu", 15f).apply { setTypeface(null, Typeface.BOLD) })
        card.put(sliderRow("Cỡ", 32, 96, store.bubbleDp, "dp") { store.bubbleDp = it; applyBubble() }, MATCH_PARENT)
        card.put(sliderRow("Độ đậm", 20, 100, store.bubblePct, "%") { store.bubblePct = it; applyBubble() }, MATCH_PARENT)
        card.put(tv("Khi ẩn menu", 15f).apply { setTypeface(null, Typeface.BOLD) })
        card.put(btn("Viền mờ chỉ vị trí gọi menu: ${if (store.hotOn) "BẬT" else "TẮT"}", GRAY) {
            store.hotOn = !store.hotOn; store.save(); renderPanel()
        }, MATCH_PARENT)
        card.put(sliderRow("Độ đậm viền", 5, 60, store.hotPct, "%") { store.hotPct = it }, MATCH_PARENT)
        c.put(card, MATCH_PARENT)
        c.put(btn("■ Dừng tất cả macro đang chạy", RED) {
            MacroAccessibilityService.inst?.stopAll(); refreshAllButtons(); renderPanel()
        }, MATCH_PARENT)
        c.put(btn("Tắt menu nổi (đóng hẳn)", DARKRED) { stopSelf() }, MATCH_PARENT)
    }

    // ---------- nhập chữ ----------
    private fun prompt(title: String, init: String, onOk: (String) -> Unit) {
        val box = col().apply {
            background = rounded(CARD, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val et = EditText(this)
        et.setText(init)
        et.setTextColor(Color.WHITE)
        et.setSingleLine()
        et.setSelection(et.text.length)
        box.put(tv(title, 15f))
        box.put(et, MATCH_PARENT)
        val r = row()
        r.put(btn("Hủy", GRAY) { rm(box) })
        r.put(btn("OK", BLUE) {
            val s = et.text.toString().trim()
            rm(box)
            if (s.isNotEmpty()) onOk(s)
        })
        box.put(r)
        val p = lp(min(dm.widthPixels - dp(40), dp(360)), WRAP_CONTENT, 0, dp(40),
            Gravity.TOP or Gravity.CENTER_HORIZONTAL, focusable = true)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(box, p)
        et.requestFocus()
    }

    // ---------- nút macro nổi ----------
    private fun label(m: Macro) = if (m.label.isEmpty()) m.name else m.label

    private fun syncButtons() {
        for (m in store.macros) {
            if (m.onScreen && !btns.containsKey(m.id)) addButton(m)
            else if (!m.onScreen && btns.containsKey(m.id)) removeButton(m.id)
        }
        btns.keys.filter { id -> store.macros.none { it.id == id } }.forEach { removeButton(it) }
    }

    private fun addButton(m: Macro) {
        val size = dp(m.btnDp)
        val p = lp(size, size, m.btnX, m.btnY)
        val v = circleView(label(m), GREEN, size, m.btnAlpha)
        drag(v, p, { arrange }, { toggleRun(m) }, { m.btnX = p.x; m.btnY = p.y; store.save() })
        wm.addView(v, p)
        btns[m.id] = v; btnP[m.id] = p
        styleButton(m)
    }

    private fun removeButton(id: Long) {
        btns.remove(id)?.let { rm(it) }
        btnP.remove(id)
    }

    private fun refreshButton(m: Macro) {
        val v = btns[m.id] ?: return
        val p = btnP[m.id] ?: return
        val size = dp(m.btnDp)
        p.width = size; p.height = size
        val pad = (size * 0.15f).toInt()
        v.setPadding(pad, pad, pad, pad)
        v.text = label(m)
        v.alpha = m.btnAlpha
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun styleButton(m: Macro) {
        val v = btns[m.id] ?: return
        val running = MacroAccessibilityService.inst?.isRunning(m.id) == true
        (v.background as? GradientDrawable)?.apply {
            setColor(if (running) ORANGE else GREEN)
            setStroke(if (arrange) dp(3) else dp(1), if (arrange) Color.YELLOW else 0x66FFFFFF)
        }
    }

    private fun refreshAllButtons() { store.macros.forEach { styleButton(it) } }
    private fun applyArrange() { refreshAllButtons() }

    private fun toggleRun(m: Macro) {
        val svc = MacroAccessibilityService.inst
        if (svc == null) { toast("Chưa bật Trợ năng cho Macro X"); return }
        if (svc.isRunning(m.id)) {
            svc.stop(m.id)
        } else {
            svc.play(m) { main.post { styleButton(m); if (panelOpen && tab == 0) renderPanel() } }
        }
        styleButton(m)
    }

    // ---------- ghi macro ----------
    private class Rec(val t: Long, val pts: MutableList<Float>)

    private fun finishRec(r: Rec?, x: Float, y: Float, endT: Long) {
        if (r == null) return
        val n = r.pts.size
        if (r.pts[n - 2] != x || r.pts[n - 1] != y) { r.pts.add(x); r.pts.add(y) }
        recSteps.add(Step(r.t, max(endT - r.t, 20L), r.pts.toList()))
    }

    private fun startRecording() {
        closePanel()
        bubble?.visibility = View.GONE
        recSteps.clear()
        val active = HashMap<Int, Rec>()
        var t0 = -1L
        val loc = IntArray(2)
        val slop = dp(6).toFloat()
        val layer = View(this)
        layer.setBackgroundColor(0x33000000)
        layer.setOnTouchListener { v, e ->
            v.getLocationOnScreen(loc)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    if (t0 < 0) t0 = e.eventTime
                    val i = e.actionIndex
                    active[e.getPointerId(i)] = Rec(e.eventTime - t0, mutableListOf(e.getX(i) + loc[0], e.getY(i) + loc[1]))
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until e.pointerCount) {
                        val r = active[e.getPointerId(i)] ?: continue
                        val n = r.pts.size
                        val x = e.getX(i) + loc[0]; val y = e.getY(i) + loc[1]
                        if (hypot(x - r.pts[n - 2], y - r.pts[n - 1]) >= slop) { r.pts.add(x); r.pts.add(y) }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                    val i = e.actionIndex
                    finishRec(active.remove(e.getPointerId(i)), e.getX(i) + loc[0], e.getY(i) + loc[1], e.eventTime - t0)
                }
                MotionEvent.ACTION_CANCEL -> {
                    for (i in 0 until e.pointerCount)
                        finishRec(active.remove(e.getPointerId(i)), e.getX(i) + loc[0], e.getY(i) + loc[1], e.eventTime - t0)
                }
            }
            true
        }
        val bar = row().apply {
            background = rounded(PANEL, 24)
            setPadding(dp(14), dp(6), dp(6), dp(6))
        }
        bar.put(tv("● Đang ghi", 14f, 0xFFFF5252.toInt()))
        bar.put(btn("Lưu", GREEN) { stopRecording(true) })
        bar.put(btn("Hủy", GRAY) { stopRecording(false) })
        wm.addView(layer, lp(MATCH_PARENT, MATCH_PARENT))
        wm.addView(bar, lp(WRAP_CONTENT, WRAP_CONTENT, 0, dp(8), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        recLayer = layer; recBar = bar
    }

    private fun stopRecording(save: Boolean) {
        recLayer?.let { rm(it) }; recBar?.let { rm(it) }
        recLayer = null; recBar = null
        bubble?.visibility = View.VISIBLE
        if (save && recSteps.isNotEmpty()) {
            val name = "Macro ${store.macros.size + 1}"
            store.macros.add(Macro(System.currentTimeMillis(), name, recSteps.sortedBy { it.t }, label = name,
                btnX = dp(80), btnY = dp(120)))
            store.save()
            toast("Đã lưu $name")
        } else if (save) toast("Chưa ghi được thao tác nào")
        tab = 0
        openPanel()
    }
}
