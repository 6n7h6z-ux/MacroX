# Macro X
Cách build: mở thư mục bằng Android Studio rồi Build > Build APK, hoặc đẩy lên GitHub (có sẵn .github/workflows/build.yml), vào tab Actions > Build APK > tải APK ở mục Artifacts.
Cách dùng: mở app, làm lần lượt nút 1 → 4.
